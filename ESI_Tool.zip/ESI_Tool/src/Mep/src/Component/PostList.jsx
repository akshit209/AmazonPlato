import React, { Component } from 'react';
import axios from 'axios'

class PostList extends Component{
    constructor(props)
    {
        super(props);

        this.state = {
            myurl: []
        }
    }

    componentDidMount(){
        axios.get('http://akshit.com:8080/instructors/ESI_Tool/hookurl')
            .then(response => {
                console.log(response)
                this.setState({myurl:response.data})
            })
            .catch(error => {
                console.log(error)
            })
    }

    render(){
       const { posts } = this.state.myurl
        return (
            <div>
                {/* List Of URL */}
                {
                   posts
                }
            </div>
        );
    }


}

export default PostList