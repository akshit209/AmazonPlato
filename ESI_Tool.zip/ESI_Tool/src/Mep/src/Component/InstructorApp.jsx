import React, { Component } from 'react';
import ListUrlComponent from './ListUrlComponent';
class InstructorApp extends Component {
    render() {
        return (<>
              <ListUrlComponent/>
              </>
        )
    }
}

export default InstructorApp