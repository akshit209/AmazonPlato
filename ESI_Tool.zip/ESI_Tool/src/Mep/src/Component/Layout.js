import React, { Component } from 'react';
import axios from 'axios';

const INSTRUCTOR = 'ESI_Tool'
const COURSE_API_URL = 'http://localhost:8080'
const INSTRUCTOR_API_URL = `${COURSE_API_URL}/instructors/${INSTRUCTOR}`

class Layout extends Component {
    render() { 
        return ( 
            <div>
                <h2>Sample punchout tester</h2>
                <p>This test will put an OCI shop on trial. Upon entering all required data, we will issue an OCI submission to the shop. You then start shopping and at some point decide to post back the shopping cart. The Meplato Validator will then intercept your response and check the returned OCI for possible sources of errors and problems.

Before you start the test consider the following:

Add at least 2 but no more than 20 items to the shopping cart. The more items, the more confidence in the results. The less items, the faster the test.
Make sure you read the customer-specific documentation for the project. This test only checks general OCI rules. Customers may have more precise requirements.
The request will always be UTF-8 encoded.</p>
            </div>
         );
    }
}
 


export default Layout;