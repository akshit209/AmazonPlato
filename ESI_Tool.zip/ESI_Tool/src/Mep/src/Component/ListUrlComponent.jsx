import React, { Component } from 'react'
import UrlDataService from '../service/UrlDataService';
import axios from 'axios'
import './my.css'

const INSTRUCTOR = 'ESI_Tool'
const COURSE_API_URL = 'http://localhost:8080'
const INSTRUCTOR_API_URL = `${COURSE_API_URL}/instructors/${INSTRUCTOR}`


class ListUrlComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            urlSession: [],
            message: null
        }
        this.onSubmit = this.onSubmit.bind(this)
        this.refreshUrlSession = this.refreshUrlSession.bind(this)
        this.addCourseClicked = this.addCourseClicked.bind(this)
    }

    componentDidMount() {
        console.log('Oh bhaiye aaja');
        axios.get(`${INSTRUCTOR_API_URL}/urlSession5`)
      .then(res => {

        console.log('beast is here')
        this.setState({ urlSession: res.data })
        console.log(this.state.urlSession)
      })

        // this.refreshUrlSession();
    }



    onSubmit(values) {
        let username = INSTRUCTOR

        let urlSession = {
            url: this.state.url,
        }

        
        console.log('ComeHere');

        UrlDataService.createCourse(username, urlSession)
                .then(
                    response => {
                        console.log(response);
                    }
                )
        

        
    }

    refreshUrlSession() {
        UrlDataService.retrieveAllUrl(INSTRUCTOR)//HARDCODED
            .then(
                response => {
                    console.log(response);
                    this.setState({ urlSession: response.data })
                }
            )
    }

    onchangeHandler = (e) =>{
        this.setState({
            url:e.target.value
        })
    }

    addCourseClicked() {
        console.log('FirstHere');
        let username = INSTRUCTOR

        let urlSession = {
            url: this.state.url,
        }

        console.log(this.state.url);
        axios.post(`${INSTRUCTOR_API_URL}/urlSession`, this.state.url).then(response =>{
            console.log(response.data);
            window.location.href = response.data;
        })

    }

    render() {
        return (
            <div className="container">
                {/* <h3>All Url</h3> */}
                <div className="container">
                    <table className="table">
                        <thead>
                            <tr>
                                {/* <th>Description</th> */}
                            </tr>
                        </thead>
                        <tbody>
                                { 
                                    // this.state.urlSession.map(
                                    // urlValue =>
                                    //     <tr key={urlValue.url}>
                                    //         <td>{urlValue.url}</td>
                                    //     </tr>
                                    // ) 
                                }
                        </tbody>
                    </table>
                    <body class="punchouts new">
<div class="container_16" id="header" role="banner">
<h1 class="grid_3 alpha"><a href="#">Amazon Validator</a></h1>
<ul class="primary-nav grid_13 omega" role="navigation">
<li><a id="nav-oci" data-no-turbolink="true" href="#"><span class="translation_missing" title="translation missing: en.shared.header.oci">Oci</span></a></li>
</ul>
<div class="clear"></div>
<div class="grid_9 prefix_3 alpha">
<ul class="secondary-nav" role="navigation">
<li><a id="nav-oci-punchouts" href="#"><span class="translation_missing" title="translation missing: en.oci.submenu.punchouts">Punchouts</span></a></li>
<li><a id="nav-oci-searches" href="#"><span class="translation_missing" title="translation missing: en.oci.submenu.searches">Searches</span></a></li>
</ul>


</div>
<div class="grid_4 omega">
<ul class="secondary-nav" role="navigation">
<li>
</li>
</ul>
</div>
<div class="clear"></div>

</div>
<div class="container_16">
<h1>New OCI punchout test</h1>

<p>
  This test will put an OCI shop on trial.
  Upon entering all required data, we will issue an OCI submission to the shop.
  You then start shopping and at some point decide to post back the shopping cart.
  The Meplato Validator will then intercept your response and check the
  returned OCI for possible sources of errors and problems.
</p>
<p>Before you start the test consider the following:</p>
<ul class='disc'>
  <li>
    Add at least 2 but no more than 20 items to the shopping cart.
    The more items, the more confidence in the results.
    The less items, the faster the test.
  </li>
  <li>
    Make sure you read the customer-specific documentation for the project.
    This test only checks general OCI rules.
    Customers may have more precise requirements.
  </li>
  <li>
    The request will always be UTF-8 encoded.
  </li>
</ul>
<p>Now please continue with entering the required data below.</p>

{/* <form class="simple_form new_oci_punchout" id="new_oci_punchout" novalidate="novalidate" action="/oci/punchouts" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="&#x2713;" /><input type="hidden" name="authenticity_token" value="545XmRN2+iPdZIf53hla9vb2HEOx1U9YV1vQwLKWKHGHGuLvvhlYGrQXlKBB7rGLCZDJSq0pZIEL52h3emAfiA==" /> */}
{/* <fieldset> */}

<div class="input url required oci_punchout_url field_with_hint"><label class="url required" for="oci_punchout_url">URL <abbr title="required">*</abbr></label><input className="ListUrlComponent" value={this.state.url} onChange={this.onchangeHandler.bind(this)} /><button className="btn btn-success" onClick={this.addCourseClicked}>Submit</button></div>
{/* <input className="ListUrlComponent" value={this.state.url} onChange={this.onchangeHandler.bind(this)} /> */}
{/* <button className="btn btn-success" onClick={this.addCourseClicked}>Submit</button> */}
<div class="input radio_buttons optional oci_punchout_http_method"><label class="radio_buttons optional">HTTP method</label><input type="hidden" name="oci_punchout[http_method]" value="" /><span class="radio"><label for="oci_punchout_http_method_get"><input class="radio_buttons optional" type="radio" value="GET" checked="checked" name="oci_punchout[http_method]" id="oci_punchout_http_method_get" />HTTP GET</label></span><span class="radio"><label for="oci_punchout_http_method_post"><input class="radio_buttons optional" type="radio" value="POST" name="oci_punchout[http_method]" id="oci_punchout_http_method_post" />HTTP POST</label></span></div>
<div class="input radio_buttons optional oci_punchout_encoding field_with_hint"><label class="radio_buttons optional">Response Encoding</label><input type="hidden" name="oci_punchout[encoding]" value="" /><span class="radio"><label for="oci_punchout_encoding_utf-8"><input class="radio_buttons optional" type="radio" value="utf-8" checked="checked" name="oci_punchout[encoding]" id="oci_punchout_encoding_utf-8" />Unicode (UTF-8)</label></span><span class="radio"><label for="oci_punchout_encoding_iso-8859-1"><input class="radio_buttons optional" type="radio" value="iso-8859-1" name="oci_punchout[encoding]" id="oci_punchout_encoding_iso-8859-1" />ISO-8859-1 (Latin 1)</label></span><span class="radio"><label for="oci_punchout_encoding_iso-8859-4"><input class="radio_buttons optional" type="radio" value="iso-8859-4" name="oci_punchout[encoding]" id="oci_punchout_encoding_iso-8859-4" />ISO-8859-4 (Baltisch)</label></span><span class="radio"><label for="oci_punchout_encoding_iso-8859-5"><input class="radio_buttons optional" type="radio" value="iso-8859-5" name="oci_punchout[encoding]" id="oci_punchout_encoding_iso-8859-5" />ISO-8859-5 (Kyrillisch)</label></span><p class="hint">Specifies the encoding of characters when returning from the shop.</p></div>
<div class="actions">
                            <div>
                            <br></br>
                                    <br></br>
                                    <br></br>
                                <h2>Past Punchout Sessions</h2>
                               
                            {this.state.urlSession.map(urlSession => ( 
                                 
                                <div key={urlSession.id}>
                                    <h3>Date: </h3><p>{urlSession.dateObj}</p>
                                    <h3>PunchOutUrl: </h3><a href="#"><p>{urlSession.url}</p></a>
                                    <h3>HookUrl</h3><a href={urlSession.hook_url}>{urlSession.hook_url}</a>
                                    <br></br>
                                    <br></br>
                                    <br></br>
                                    <br></br>
                                    <br></br>
                                </div>
                    ))
                }
                            </div>
{/* <input type="submit" name="commit" value="Create and call shop" class="button button" data-disable-with="Create and call shop" /> */}
{/* <input className="ListUrlComponent" value={this.state.url}onChange={this.onchangeHandler.bind(this)} />
<button className="btn btn-success" onClick={this.addCourseClicked}>Submit</button> */}

or
<a href="#">Cancel</a>
</div>
{/* </fieldset> */}
{/* </form> */}
</div>

</body>
                </div>
            </div>
        )
    }
}

export default ListUrlComponent