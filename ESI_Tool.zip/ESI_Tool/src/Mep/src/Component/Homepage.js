import React, { Component } from 'react';



class Homepage extends Component{
    


    
    render(){
        return (

            <body class="punchouts index">
<div class="container_16" id="header" role="banner">
<h1 class="grid_3 alpha"><a href="http://validator.meplato.de/">Meplato Validator</a></h1>
<ul class="primary-nav grid_13 omega" role="navigation">
<li><a id="nav-oci" data-no-turbolink="true" href="http://validator.meplato.de/oci/punchouts"><span class="translation_missing" title="translation missing: en.shared.header.oci">Oci</span></a></li>
</ul>
<div class="clear"></div>
<div class="grid_9 prefix_3 alpha">
<ul class="secondary-nav" role="navigation">
<li><a id="nav-oci-punchouts" href="http://validator.meplato.de/oci/punchouts"><span class="translation_missing" title="translation missing: en.oci.submenu.punchouts">Punchouts</span></a></li>
<li><a id="nav-oci-searches" href="http://validator.meplato.de/oci/searches"><span class="translation_missing" title="translation missing: en.oci.submenu.searches">Searches</span></a></li>
</ul>


</div>
<div class="grid_4 omega">
<ul class="secondary-nav" role="navigation">
<li>
</li>
</ul>
</div>
<div class="clear"></div>

</div>
<div class="container_16">
<div class="grid_11 headline">
<h1>Your latest OCI punchouts</h1>
</div>
<div class="grid_5 headline buttons">
<a class="button" href="/punchout">New OCI punchout test</a>
</div>
<div class="clear"></div>
<div class="grid_16">

<p>You haven&#39;t started any OCI punchouts yet.</p>
<br></br>
<p><a class="button" href="/punchouts">New OCI punchout test</a></p>
</div>

</div>

</body>
        );
    }


}

export default Homepage

