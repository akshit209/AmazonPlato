import axios from 'axios'

const INSTRUCTOR = 'ESI_Tool'
const COURSE_API_URL = 'http://localhost:8080'
const INSTRUCTOR_API_URL = `${COURSE_API_URL}/instructors/${INSTRUCTOR}`

class UrlDataService {

    retrieveAllUrl(name) {
        return axios.get(`${INSTRUCTOR_API_URL}/urlSession`);
    }

    createCourse(name, urlSession) {
        
        return axios.post(`${INSTRUCTOR_API_URL}/urlSession/`, urlSession);
    }
}

export default new UrlDataService()
