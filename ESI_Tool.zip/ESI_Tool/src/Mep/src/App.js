import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Layout from './Component/Layout'
import InstructorApp from './Component/InstructorApp'
import PostList from './Component/PostList'
import {BrowserRouter as Router, Route} from 'react-router-dom'
import Homepage from './Component/Homepage'

function App() {
  return (
    <Router>
    <div>
    <Route exact path="/" component={Homepage} />
    <Route exact path="/punchout" component={InstructorApp} />
      {/* <InstructorApp /> */}
      {/* <PostList/> */}

    </div>
    </Router>
  );
}

export default App;
