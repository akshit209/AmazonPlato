package com.example.ESI_Tool.urlSession;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

import java.net.URL;

@DynamoDBTable(tableName = "Tool_Check")
public class UrlSession {

    private URL url;
    private String id;
    private URL hook_url;
    private String hashmap;
    private String dateObj;


    public UrlSession(){}

    public UrlSession(URL url, URL hook_url, String id) {
        this.url = url;
        this.id = id;
        this.hook_url = hook_url;
    }

    public UrlSession(URL url, URL hook_url, String id, String hashmap, String dateObj) {
        this.url = url;
        this.id = id;
        this.hook_url = hook_url;
        this.hashmap = hashmap;
        this.dateObj = dateObj;
    }

    @DynamoDBHashKey(attributeName = "id")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @DynamoDBAttribute(attributeName = "url")
    public URL getUrl() {
        return url;
    }
    public void setUrl(URL url) {
        this.url = url;
    }

    @DynamoDBAttribute(attributeName = "hook_url")
    public URL getHookUrl() {
        return hook_url;
    }
    public void setHookUrl(URL hook_url) {
        this.hook_url = hook_url;
    }

    @DynamoDBAttribute(attributeName = "hashmap")
    public String getHashmap() {
        return hashmap;
    }
    public void setHashmap(String hashmap) {
        this.hashmap = hashmap;
    }

    @DynamoDBAttribute(attributeName = "dateObj")
    public String getDateObj() {
        return dateObj;
    }
    public void setDateObj(String dateObj) {
        this.dateObj = dateObj;
    }

}
