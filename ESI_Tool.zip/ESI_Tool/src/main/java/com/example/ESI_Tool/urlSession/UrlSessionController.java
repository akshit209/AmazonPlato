package com.example.ESI_Tool.urlSession;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import static java.util.UUID.randomUUID;

@RestController
@CrossOrigin("*")
public class UrlSessionController {

        @Autowired
        private UrlSessionService urlSessionService;
        private String urlModel;
        private String unique_id;
        private String hook_url;

        @GetMapping("/instructors/{username}/urlSession")
        public List<URL> getAllMyCourses(@PathVariable String username) {
            return urlSessionService.findAll();
        }

        @GetMapping("/instructors/{username}/urlSession5")
        public String getAllMyCourses5(@PathVariable String username) {
            List<UrlSession>result =  urlSessionService.findAll2();

            Gson object = new Gson();
            String value = object.toJson(result);
            System.out.println(value);
            return value;

        }

        @PostMapping("/instructors/{username}/urlSession")
        public String createCourse(@PathVariable String username, @RequestBody String urlSession,
                                 HttpServletRequest request, HttpServletResponse response) throws IOException {

                if(urlSession.length() != 0){
                    int firstOccurence = urlSession.indexOf("username");

                    if(firstOccurence != -1)
                    {
                        String directedURL = urlSession.substring(0,firstOccurence);
                        String credential = urlSession.substring(firstOccurence);

                        urlModel = urlSession;
                        String DecodeUrl = "";
                        try {
                            DecodeUrl = URLDecoder.decode(directedURL, "UTF-8");
                            urlModel = DecodeUrl+credential;
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }

                        unique_id = randomUUID().toString();
                        String masterdecodeurl = "http://akshit.com:8080/instructors/ESI_Tool/" + unique_id;
                        hook_url = masterdecodeurl;

                        String master = urlModel + "&HOOK_URL=" + masterdecodeurl;
                        return master;
                    }
                    else
                    {
                        urlModel = urlSession.substring(0,urlSession.length()-1);
                        String DecodeUrl = "";

                        try {
                            DecodeUrl = URLDecoder.decode(urlModel, "UTF-8");
                            urlModel = DecodeUrl;
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }

                        unique_id = randomUUID().toString();
                        String masterdecodeurl = "http://akshit.com:8080/instructors/ESI_Tool/" + unique_id;
                        hook_url = masterdecodeurl;

                        URL url_test = null;
                        try {
                            url_test = new URL(urlModel);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        URL hook_url_test = null;
                        try {
                            hook_url_test = new URL(hook_url);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }

                        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                        LocalDateTime now = LocalDateTime.now();
                        String datevalue = now.toString();
                        UrlSession urlSession1 = new UrlSession(url_test, hook_url_test, unique_id, "", datevalue);

//                        UrlSession urlSession1 = new UrlSession(url_test, hook_url_test, unique_id);
                        urlSessionService.uploadUrlInDatabase(urlSession1);

//                        String master = urlModel + "&HOOK_URL=" + masterdecodeurl;
                        return urlModel;
                    }
                }
                String res="";
                return res;
        }

    @PostMapping("/instructors/{username}/{unique_id}")
    public String createCourse2(HttpServletRequest request, HttpServletResponse response)
    {
        Gson object = new Gson();
        Map<String , String[]> hashmap = request.getParameterMap();
        String value = object.toJson(hashmap);

        URL url_test = null;
        try {
            url_test = new URL(urlModel);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        URL hook_url_test = null;
        try {
            hook_url_test = new URL(hook_url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String datevalue = now.toString();
        UrlSession urlSession = new UrlSession(url_test, hook_url_test, unique_id, value, datevalue);
        urlSessionService.uploadUrlInDatabase(urlSession);

        return value;
    }

    @GetMapping("/instructors/{username}/{unique_id}")
    public String displayPOOM(HttpServletRequest request, HttpServletResponse response)
    {
       String fhook =  request.getRequestURI();
       int index = fhook.lastIndexOf("/");
       String unique_id_map = fhook.substring(index+1);
        String value = urlSessionService.findhashmap(unique_id_map);
        return value;
    }

}
