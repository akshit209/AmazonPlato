package com.example.ESI_Tool.FileStore;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.example.ESI_Tool.urlSession.UrlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FileStore {
    private final AmazonDynamoDB dbClient;

    @Autowired
    public FileStore(AmazonDynamoDB dbClient) {
        this.dbClient = dbClient;
    }


    public List<UrlSession> getAllSessionInfo(){

        DynamoDBMapper mapper = new DynamoDBMapper(dbClient);
        DynamoDB dynamoDB = new DynamoDB(dbClient);

        DynamoDBScanExpression scanExpression = new DynamoDBScanExpression();
        PaginatedScanList<UrlSession> itemList = mapper.scan(UrlSession.class, scanExpression);

        return itemList;

    }

    public String gethashMap(String unique_id)
    {
        DynamoDBMapper mapper = new DynamoDBMapper(dbClient);
        DynamoDB dynamoDB = new DynamoDB(dbClient);
        UrlSession partitionKey = new UrlSession();
        partitionKey.setId(unique_id);

        DynamoDBQueryExpression<UrlSession> queryExpression = new DynamoDBQueryExpression<UrlSession>().withHashKeyValues(partitionKey);
        PaginatedQueryList<UrlSession>queryList = mapper.query(UrlSession.class, queryExpression);
        if(queryList.size() == 0)
        {
            return "";
        }
        return queryList.get(0).getHashmap();
    }

    public void save(UrlSession url){
        DynamoDBMapper mapper = new DynamoDBMapper(dbClient);
        DynamoDB dynamoDB = new DynamoDB(dbClient);
        mapper.save(url);
    }
}
